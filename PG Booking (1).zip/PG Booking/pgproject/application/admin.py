from django.contrib import admin
from . models import Register1,Register4,Contact3, Registerpg,Feed2,Applypg,Sendreq1
admin.site.register(Register1)
admin.site.register(Register4)
admin.site.register(Contact3)
admin.site.register(Registerpg)
admin.site.register(Feed2)
admin.site.register(Applypg)
admin.site.register(Sendreq1)

